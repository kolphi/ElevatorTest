package sqelevator.application.model;

public enum ElevatorCommands {
	SET_TARGET,
	SET_STOP_REQUEST,
}
