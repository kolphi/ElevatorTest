package sqelevator.application.model;

public enum FloorCommands {
	GET_FLOOR_BUTTON, 
	GET_FLOOR_BUTTON_UP, 
	GET_FLOOR_BUTTON_DOWN
}
